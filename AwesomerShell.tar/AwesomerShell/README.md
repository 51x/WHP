# AwesomerShell
This is the awesomershell application code that was presented with the Gray Hat PowerShell talk.
