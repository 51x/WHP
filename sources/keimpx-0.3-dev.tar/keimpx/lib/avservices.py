AVSERVICES = {
    'MsMpSvc': 'Microsoft Antimalware Service',
    'AntiVirService': 'Avira Real-Time Protection'
}
